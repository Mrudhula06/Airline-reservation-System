package com.example.demo;

public class App {
    public static void main(String args[])
    {
        ARS.main(args);
    }
}
//command